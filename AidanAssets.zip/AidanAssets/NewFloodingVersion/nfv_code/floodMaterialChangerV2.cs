using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class floodMaterialChangerV2 : MonoBehaviour
{
    public static floodMaterialChangerV2 Instance { get; private set; }

    public static int MESH_ARRAY_LENGTH = 22;


    public MeshRenderer[] floodObjects = new MeshRenderer[MESH_ARRAY_LENGTH]; //contains all objects that need to be changed

    #region clearWaterPreset
    public static Dictionary<int, (Color color, float opacity)> clearWaterPreset_Colors 
        = new Dictionary<int, (Color color, float opacity)>
    {
        //1. shallowWater: ("147D7C"), 117
        [0] = (new Color32(0x14, 0x7D, 0x7C, 0x75), 117f),

        //2. deepWater: ("16714A"), 146
        [1] = (new Color32(0x16, 0x71, 0x4A, 0x92), 146f),

        //3. foam: ("FEFFDF"), 255
        [2] = (new Color32(0xFE, 0xFF, 0xDF, 0xFF), 255f),

        //4. waterBase: ("504422"), 255
        [3] = (new Color32(0x50, 0x44, 0x22, 0xFF), 255f)
    };

    public static Dictionary<int, float[]> clearWaterPreset = new Dictionary<int, float[]>
    {
        // clearTop
        [0] = new float[] {10, 0.5f, 0.05f, 3, 0.01f, 0.2f, 7.97f, 1, 300, 1, 0.05f},

        // clearTop2
        [1] = new float[] {10, 0.5f, 0.05f, 3, 0.01f, 0, 0, 0, 0, 1, -0.05f},

        // clearBottom
        [2] = new float[] {10, 0.5f, 0.05f, 3, 0.01f, 0, 0, 0, 0, 0, 0},

        // clearBottom2
        [3] = new float[] {10, 0.5f, 0.05f, 3, 0.01f, 0, 0, 0, 0, 0, 0}, 
            //even though its the same as clearBottom, needs to stay separate for indexing purposes

        // clearBottom_BASE
        [4] = new float[] {0, 0.5f, 0, 0, 0, 0, 0, 0, 0, 0, 0},

        // clearBottom2_BASE
        [5] = new float[] {0, 0.5f, 0, 0, 0, 0, 0, 0, 0, 0, 0},

        // clearSideBack
        [6] = new float[] {10, 0.5f, 0.01f, 0.1f, 0.01f, 0, 0, 0, 0, 1, -10},

        // clearSideFront
        [7] = new float[] {10, 0.5f, 0.01f, 0.1f, 0.01f, 0, 0, 0, 0, 1, -10},

        // clearSideLeft
        [8] = new float[] {10, 0.5f, 0.01f, 0.1f, 0.01f, 0, 0, 0, 0, 1, -10},

        // clearSideRight
        [9] = new float[] {10, 0.5f, 0.01f, 0.1f, 0.01f, 0, 0, 0, 0, 1, -10},

        // clearSideBack2
        [10] = new float[] {10, 0.5f, 0.01f, 0.1f, 0.01f, 0, 0, 0, 0, 1, 10},

        // clearSideFront2
        [11] = new float[] {10, 0.5f, 0.01f, 0.1f, 0.01f, 0, 0, 0, 0, 1, 10},

        // clearSideLeft2
        [12] = new float[] {10, 0.5f, 0.01f, 0.1f, 0.01f, 0, 0, 0, 0, 1, 10},

        // clearSideRight2
        [13] = new float[] {10, 0.5f, 0.01f, 0.1f, 0.01f, 0, 0, 0, 0, 1, 10},

        // clearSideBack_BASE
        [14] = new float[] {10, 0.5f, 0.01f, 0.1f, 0.01f, 0, 0, 0, 0, 0, 0},

        // clearSideFront_BASE
        [15] = new float[] {10, 0.5f, 0.01f, 0.1f, 0.01f, 0, 0, 0, 0, 0, 0},

        // clearSideLeft_BASE
        [16] = new float[] {10, 0.5f, 0.01f, 0.1f, 0.01f, 0, 0, 0, 0, 0, 0},

        // clearSideRight_BASE
        [17] = new float[] {10, 0.5f, 0.01f, 0.1f, 0.01f, 0, 0, 0, 0, 0, 0},

        // clearSideBack2_BASE
        [18] = new float[] {10, 0.5f, 0.01f, 0.1f, 0.01f, 0, 0, 0, 0, 0, 0},

        // clearSideFront2_BASE
        [19] = new float[] {10, 0.5f, 0.01f, 0.1f, 0.01f, 0, 0, 0, 0, 0, 0},

        // clearSideLeft2_BASE
        [20] = new float[] {10, 0.5f, 0.01f, 0.1f, 0.01f, 0, 0, 0, 0, 0, 0},

        // clearSideRight2_BASE
        [21] = new float[] {10, 0.5f, 0.01f, 0.1f, 0.01f, 0, 0, 0, 0, 0, 0}
    };//endof clearWater dictionary
    /* 
        All Material Presets:

        Clear water preset:

        ---Everything uses only these colors (use an index instead of color info)---
            1. shallow water = 147D7C, 117 
            2. deep water = 16714A, 146
            3. foam = FEFFDF, 255
            4. water base = 504422, 255
        ----------------------------------------

            - clearTop has 'waterFoamWaves'

                colors (hex number, opacity):
                    shallow water = 147D7C, 117 
                    deep water = 16714A, 146
                    foam = FEFFDF, 255
                floats:
                    water depth = 10
                    alpha = 0.5
                    refractSpeed = 0.05
                    refractScale = 3
                    refractStrength = 0.01
                    foamAmount = 0.2
                    foamCutoff = 7.97
                    foamSpeed = 1
                    foamScale = 300
                    waveSpeed = 1
                    waveStrength = 0.05

            - clearTop2 has 'waterWavesREVERSE'

                colors (hex number, opacity):
                    shallow water = 147D7C, 117 
                    deep water = 16714A, 146

                floats:
                    water depth = 10
                    alpha = 0.5
                    refractSpeed = 0.05
                    refractScale = 3
                    refractStrength = 0.01
                    waveSpeed = 1
                    waveStrength = -0.05

            - clearBottom, clearBottom2 has 'waterStatic'

                colors (hex number, opacity):
                    shallow water = 147D7C, 117 
                    deep water = 16714A, 146

                floats:
                    water depth = 10
                    alpha = 0.5
                    refractSpeed = 0.05
                    refractScale = 3
                    refractStrength = 0.01

            - clearBottom_BASE, clearBottom2_BASE has 'waterBase'

                colors (hex number, opacity)::
                  all colors = 504422, 255
                floats:
                    water depth = 0
                    alpha = 0.5
                    refractSpeed = 0
                    refractScale = 0
                    refractStrength = 0

            - clearSideBack, clearSideFront, 
              clearSideLeft, clearSideRight has 'waterWavesSIDE_REVERSE'

                colors (hex number, opacity):
                    shallow water = 147D7C, 117 
                    deep water = 16714A, 146

                floats:
                    water depth = 10
                    alpha = 0.5
                    refractSpeed = 0.01
                    refractScale = 0.1
                    refractStrength = 0.01
                    waveSpeed = 1
                    waveStrength = -10

            - clearSideBack2, clearSideFront2, 
              clearSideLeft2, clearSideRight2 has 'waterWavesSIDE'

                colors (hex number, opacity):
                    shallow water = 147D7C, 117 
                    deep water = 16714A, 146

                floats:
                    water depth = 10
                    alpha = 0.5
                    refractSpeed = 0.01
                    refractScale = 0.1
                    refractStrength = 0.01
                    waveSpeed = 1
                    waveStrength = 10

            - clearSideBack_BASE, clearSideFront_BASE, 
              clearSideLeft_BASE, clearSideRight_BASE,
              clearSideBack2_BASE, clearSideFront2_BASE, 
              clearSideLeft2_BASE, clearSideRight2_BASE has 'waterStaticSIDE'

              colors (hex number, opacity):
                    shallow water = 147D7C, 117 
                    deep water = 16714A, 146

                floats:
                    water depth = 10
                    alpha = 0.5
                    refractSpeed = 0.01
                    refractScale = 0.1
                    refractStrength = 0.01

        For dictionary float[]:
            [0] = waterDepth  
            [1] = alpha  
            [2] = refractSpeed  
            [3] = refractScale  
            [4] = refractStrength  
            [5] = foamAmount  
            [6] = foamCutoff  
            [7] = foamSpeed  
            [8] = foamScale  
            [9] = waveSpeed  
            [10] = waveStrength
    */
    #endregion

    #region greyWaterPreset

    public static Dictionary<int, (Color color, float opacity)> greyWaterPreset_Colors 
        = new Dictionary<int, (Color color, float opacity)>
    {
        //1. shallowWater: ("6E6A5E"), 117
        [0] = (new Color32(0x6E, 0x6A, 0x5E, 0x75), 146f),  // #6E6A5E

        //2. deepWater: ("444536"), 146
        [1] = (new Color32(0x44, 0x45, 0x36, 0x92), 175f),  // #444536

        //3. foam: ("DDDDCC"), 255
        [2] = (new Color32(0xDD, 0xDD, 0xCC, 0xFF), 255f),  // #DDDDCC

        //4. waterBase: ("33281A"), 255
        [3] = (new Color32(0x33, 0x28, 0x1A, 0xFF), 255f)   // #33281A
    };
    #endregion

    #region blackWaterPreset

    public static Dictionary<int, (Color color, float opacity)> blackWaterPreset_Colors 
        = new Dictionary<int, (Color color, float opacity)>
    {
        // 1. Shallow Water — sickly dark olive/greenish-brown
        [0] = (new Color32(0x2E, 0x2D, 0x1A, 0x75), 200f),  // #2E2D1A

        // 2. Deep Water — nearly black with subtle green-purple undertones
        [1] = (new Color32(0x13, 0x14, 0x12, 0x92), 223f),  // #131412

        // 3. Foam — toxic grey-yellowish foam (decay)
        [2] = (new Color32(0xB4, 0xB2, 0x91, 0xFF), 255f),  // #B4B291

        // 4. Water Base — oily black sludge
        [3] = (new Color32(0x0A, 0x0A, 0x0A, 0xFF), 255f)   // #0A0A0A
    };

    #endregion

    public GameObject cubeHolder;

    private Coroutine opacityRoutine = null;
    private Coroutine matTransition = null;

    #region initialization
    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }//endof if

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }
    // Start is called before the first frame update
    void Start()
    {   
        Material tmpMat;
        float[] currentArray;

        for (int i = 0; i < MESH_ARRAY_LENGTH; i++) { //set the whole cube to that current material
            if (floodObjects[i] == null) {
                Debug.LogError("Flood Object " + i + " is missing.");
                continue;
            }

            tmpMat = floodObjects[i].material;
  
            if (clearWaterPreset.TryGetValue(i, out currentArray)) {
                //all shaders should have these
                tmpMat.SetFloat("_waterDepth", currentArray[0]);
                tmpMat.SetFloat("_alpha", currentArray[1]);
                tmpMat.SetFloat("_RefractSpeed", currentArray[2]);
                tmpMat.SetFloat("_RefractScale", currentArray[3]);
                tmpMat.SetFloat("_RefractStrength", currentArray[4]);

                //these only apply to certain shaders; add switch to avoid extra operations?
                tmpMat.SetFloat("_FoamAmount", currentArray[5]);
                tmpMat.SetFloat("_FoamCutoff", currentArray[6]);
                tmpMat.SetFloat("_FoamSpeed", currentArray[7]);
                tmpMat.SetFloat("_FoamScale", currentArray[8]);

                tmpMat.SetFloat("_waveSpeed", currentArray[9]);
                tmpMat.SetFloat("_waveStrength", currentArray[10]);

            }//endof if

        }//endof for
      

        if (cubeHolder == null) Debug.LogError("object holding the cube is not assigned.");

    }//endof start method

    #endregion


    #region floodCube helper methods
    public void cubeSwitch() {
        /*
        //if mesh will be visible and it wasn't previously
        if (cubeHolder != null && !cubeHolder.activeSelf) 
            cubeHolder.SetActive(true); //turn on the cube

        else if (cubeHolder != null && cubeHolder.activeSelf) 
            cubeHolder.SetActive(false); //turn off the cube
        else 
            Debug.LogError("cube switch didn't work :("); //error*/
        if (floodObjects[0].material.GetFloat("_alpha") != 0f)
            SetOpacity(0f);
        else SetOpacity(1f);

    }

    //lets other classes/methods access change material methods with a smooth transition
    public void changeMaterialFrontend(int whichFlood) {
        if (whichFlood < 1 || whichFlood > 3) {
            Debug.LogError("Invalid flood index");
            return;
        }
        //do cmt then cm
        if (matTransition != null) StopCoroutine(matTransition); //don't let anything interrupt, so it doesn't break
        matTransition = StartCoroutine(changeMatTransition(whichFlood)); //if coroutine running, stop prev routine and start new one
        
    }
    public IEnumerator changeMatTransition(int whichFlood) {
        Debug.Log("A1 material transition method called!!!");
         //target opacity, duration, bool for turning off the cube
        changeOpacity(0f, 1f); //set opacity to zero without turning off objects

        yield return new WaitForSeconds(0.3f); //wait

        changeMaterial(whichFlood); //change the material WITHOUT changing opacity

        changeOpacity(0.5f, 3f); //slowly change opacity; the duration is arbitrary
         Debug.Log("A1 material transition method finished!!!");
    }

        //changes the material of the flood; currently only affects color
    public void changeMaterial(int whichFlood) {
        Material tmpMat;

        switch(whichFlood) { //based on which kind of flood
            case 1: //clear
                for (int i = 0; i < MESH_ARRAY_LENGTH; i++) {//change materials
                    tmpMat = floodObjects[i].material; //assign current material

                    if (clearWaterPreset_Colors.TryGetValue(0, out var shallow))
                        tmpMat.SetColor("_shallowWater", shallow.color);
                    if (clearWaterPreset_Colors.TryGetValue(1, out var deep))
                        tmpMat.SetColor("_deepWater", deep.color);
                    if (clearWaterPreset_Colors.TryGetValue(2, out var foam))
                        tmpMat.SetColor("_foam", foam.color);
                    if (clearWaterPreset_Colors.TryGetValue(3, out var baseCol))
                        tmpMat.SetColor("_waterBase", baseCol.color);
                    
                }
                break;

            case 2: //grey
                for (int i = 0; i < MESH_ARRAY_LENGTH; i++) {//change materials
                    tmpMat = floodObjects[i].material; //assign current material

                    if (greyWaterPreset_Colors.TryGetValue(0, out var shallow))
                        tmpMat.SetColor("_shallowWater", shallow.color);
                    if (greyWaterPreset_Colors.TryGetValue(1, out var deep))
                        tmpMat.SetColor("_deepWater", deep.color);
                    if (greyWaterPreset_Colors.TryGetValue(2, out var foam))
                        tmpMat.SetColor("_foam", foam.color);
                    if (greyWaterPreset_Colors.TryGetValue(3, out var baseCol))
                        tmpMat.SetColor("_waterBase", baseCol.color);

                }
                break;
            case 3: //black
                for (int i = 0; i < MESH_ARRAY_LENGTH; i++) {//change materials
                    tmpMat = floodObjects[i].material; //assign current material

                    if (blackWaterPreset_Colors.TryGetValue(0, out var shallow))
                        tmpMat.SetColor("_shallowWater", shallow.color);
                    if (blackWaterPreset_Colors.TryGetValue(1, out var deep))
                        tmpMat.SetColor("_deepWater", deep.color);
                    if (blackWaterPreset_Colors.TryGetValue(2, out var foam))
                        tmpMat.SetColor("_foam", foam.color);
                    if (blackWaterPreset_Colors.TryGetValue(3, out var baseCol))
                        tmpMat.SetColor("_waterBase", baseCol.color);

                }
                break;
        }//endof switch

    }

    //will allow other methods to access the opacity slider in this method
    public void changeOpacity(float targetOpacity, float duration) {
        Debug.Log("A1 Currently changing opacity!!!");
        if (opacityRoutine != null) StopCoroutine(opacityRoutine);
        else opacityRoutine = StartCoroutine(SetOpacitySlow(targetOpacity, duration));
    }

    #endregion


    #region OpacityMethods

    public void SetOpacity(float targetOpacity)
    { //set opacity immediately
        for (int i = 0; i < MESH_ARRAY_LENGTH; i++)
        {
            floodObjects[i].material.SetFloat("_alpha", targetOpacity);
        }//make sure its the correct opacity at the end
    }//endof method

    private IEnumerator SetOpacitySlow(float targetOpacity, float duration) { //set opacity slower

        
        float elapsed = 0f, startAlpha = 0f, currentAlpha = 0f; //elapsed time, start and current alpha (for loop use)


        startAlpha = floodObjects[0].material.GetFloat("_alpha");
        Debug.Log("A1 Currently changing opacity with slow method!!!");
        while (elapsed < duration) {
            elapsed += Time.deltaTime;
            currentAlpha = Mathf.Lerp(startAlpha, targetOpacity, elapsed / duration);

            // Set alpha for all materials *once per frame*
            for (int i = 0; i < MESH_ARRAY_LENGTH; i++)
            {
                floodObjects[i].material.SetFloat("_alpha", currentAlpha);
            }


            yield return null; //wait for operations
        }//endof while 

        Debug.Log("A1  opacity changed in slow method!!!");
        for (int i = 0; i < MESH_ARRAY_LENGTH; i++)
        {
            floodObjects[i].material.SetFloat("_alpha", targetOpacity);
        }//make sure its the correct opacity at the end
       
    } //endof method

    #endregion
}
