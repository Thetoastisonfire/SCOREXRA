using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class FloodCubeBuilder : MonoBehaviour
{

    #region Variables 

    [Header("Cube Objects")]
    public Transform bottomPlane;
    public Transform topPlane;
    public Transform sideFront;
    public Transform sideBack;
    public Transform sideLeft;
    public Transform sideRight;

    private Vector3 sideStartScale; //they should all be the same scale, because the top and bottom are a flat surface
    private Vector3 sideCurrentScale; //current scale

    private Vector3 bottomStartPos;
    private Vector3 topCurrentPos; //current top position
    private Vector3 topStartPos; //starting position of top
    private Vector3 sideFrontStartPos;
    private Vector3 sideBackStartPos;
    private Vector3 sideLeftStartPos;
    private Vector3 sideRightStartPos;

    [Header("Flood Height Slider")]
    public Slider floodHeightSlider;
    private bool currentlyUsingSlider = false;
    private float currentSliderHeightA = 0f; //using rolling pointer in case of slider value and height value discrepancy
    private float currentSliderHeightB = 0f;
    private Coroutine delayedSliderRoutine = null;

    [Header("Measurements")]
    private float seaLevel = -1f;
    public const int floodHeightLimit = 100;
    public const float cubeWidth = 1f; // assume square base

    [Header("Transition Speed")]
    public const float growthSpeed = 2f; //things grow at this speed (they finish in N seconds)
    private Coroutine growCoroutine = null;
    private Coroutine buttonDisableRoutine = null;
    private Coroutine floodSounds = null;
    private bool buttonsOnCooldown = false; //if flood buttons are on cooldown
    private int floodIsOn = 0; //logs currently active flood

    #endregion


    void Start() {
        //store initial cube scale
        sideStartScale = sideFront.localScale;
        sideCurrentScale = sideStartScale;

        //store initial cube positions
        bottomStartPos = bottomPlane.position;
        topCurrentPos = topPlane.position;
        topStartPos = topPlane.position;
        sideFrontStartPos = sideFront.position;
        sideBackStartPos = sideBack.position;
        sideLeftStartPos = sideLeft.position;
        sideRightStartPos = sideRight.position;

        //sea level is the starting position
        seaLevel = topPlane.position.y;
    }
/*
    #region testing code
    //FOR TESTING
    private float time = 0f;
    private int growingTest = 1; //0.01f is approximately 1 meter maybe; handled in StartGrowing()

    public void Update() {
        time += Time.deltaTime;

        if (time > 5f) { //because modulo doesn't work with floats
            if (growingTest <= 4) { //run test 5 times, then return to original level and repeat test
                //changeFloodLevel(growingTest, 2f);
                complicatedButton(growingTest); //cycle through button presses
                Debug.Log("button " + growingTest + "has been pressed.");
                growingTest++;
            } else {
                growingTest = 1;
                complicatedButton(growingTest); //zero indicates 'sea level'
                growingTest++;
            }
            time = 0f;
        }//endof if
    }

    #endregion
*/


    #region buttons
    private IEnumerator bubblingFlood() {
        int loopCount = 0, maxLoops = 100;
        while (floodIsOn != 0 && (loopCount < maxLoops)) {
           /* if (floodSounds != null) StopCoroutine(floodSounds); //add fade out audio methods to that
            floodSounds = StartCoroutine(SoundManagerScript.Instance.PlayAudioClip("bubbling", 2)); 
*/
            yield return new WaitForSeconds(5f);

            loopCount++;

            yield return null; // let one frame pass between loops
        }

        if (floodIsOn != 0) StartCoroutine(bubblingFlood());
    }
    public void turnOnFlood(int whichFlood) { //turns on the specified flood at a default 5 meter height
        /*
           1 = clear water, 2 = grey water, 3 = black water, all start at 5 meters of flood; also 4 = RESET everything
        */

       /* //turn on the cube if it was turned off
        if (!floodMaterialChanger.Instance.cubeHolder.activeSelf) {
            //make sure opacity is turned off before fading in
            floodMaterialChanger.Instance.SetOpacity(
                floodMaterialChanger.Instance.floodObjects[0].sharedMaterial, 0f, false);
            floodMaterialChanger.Instance.cubeHolder.SetActive(true);
        */
        if (!floodMaterialChangerV2.Instance.cubeHolder.activeSelf) {
            //make sure opacity is turned off before fading in
            floodMaterialChangerV2.Instance.SetOpacity(0f);
            floodMaterialChangerV2.Instance.cubeHolder.SetActive(true);
            /*    StartCoroutine(SoundManagerScript.Instance.PlayAudioClip("biggerWave", 2));*/
        }
        
        changeFloodLevel(5, growthSpeed); //will flood to 5 meters at the designated flood growth speed
      
      /*  floodMaterialChanger.Instance.changeMaterialFrontend(whichFlood);
        floodMaterialChanger.Instance.changeOpacity(
                floodMaterialChanger.Instance.materials_StartOpacity[floodMaterialChanger.Instance.theMaterialIndex-1], growthSpeed, true);
                //This is a very long method call, but its just setting the opacity to the current material's starting opacity
        */

        floodMaterialChangerV2.Instance.changeMaterialFrontend(whichFlood);
        floodMaterialChangerV2.Instance.changeOpacity(0.5f, growthSpeed); //cause the color opacities are built-in
        
    }

    public void turnOffFlood(bool andTurnOffObject) { //turns off the current flood
        changeFloodLevel(0, growthSpeed); //changes to sea level
       // floodMaterialChanger.Instance.changeOpacity(0f, growthSpeed, andTurnOffObject); //turn material invisible
        floodMaterialChangerV2.Instance.changeOpacity(0f, growthSpeed);
    }

    private IEnumerator buttonDisableRn() //disable all buttons until the small cooldown is done
    {
        buttonsOnCooldown = true;
        yield return new WaitForSeconds(0.3f);
        buttonsOnCooldown = false;
    }

        //this should only run after 2? seconds of inactivity
    private IEnumerator RunSliderMethodAgain()
    {
        yield return new WaitForSeconds(growthSpeed);
        sliderForFlood();
    }
    public void OnSliderReleased(BaseEventData eventData) {
        float finalValue = floodHeightSlider.value;
        currentSliderHeightA = finalValue;
       // Debug.Log("Slider stopped at: " + finalValue);
        sliderForFlood();

        //re-run the method to make sure its at the correct slider height
        if (delayedSliderRoutine != null)
            StopCoroutine(delayedSliderRoutine);

        delayedSliderRoutine = StartCoroutine(RunSliderMethodAgain());

    }
    #endregion

    #region frontend methods
        //method for slider that controls water height
    private IEnumerator resetSlider(int resetToWhat) {
        currentlyUsingSlider = true; //so it doesn't try to reset every time the slider moves in increments

        if (floodHeightSlider.value > resetToWhat) { //if slider is greater, go down
            while (floodHeightSlider.value > resetToWhat) {
                floodHeightSlider.value = floodHeightSlider.value - 1f;
                yield return new WaitForSeconds(0.05f);
            }
        } else if (floodHeightSlider.value < resetToWhat) { //if slider is less, go up
            while (floodHeightSlider.value < resetToWhat) {
                floodHeightSlider.value = floodHeightSlider.value + 1f;
                yield return new WaitForSeconds(0.05f);
            }
        }
        sliderForFlood(); //run so no discrepancies between flood height and actual slider value
        currentlyUsingSlider = false;
    }
    public void sliderForFlood() {
        if (buttonsOnCooldown || currentlyUsingSlider) {
            floodHeightSlider.value = currentSliderHeightB;// maybe not needed with release slider code?
            //maybe play EEENK sound to minimize disconcertion?
            return; //to prevent double-clicking and rapid clicking
        } 
        else {
            if (buttonDisableRoutine != null) StopCoroutine(buttonDisableRoutine);
            buttonDisableRoutine = StartCoroutine(buttonDisableRn()); //disables button for 0.3 seconds
        }
        int sliderValue = (int) floodHeightSlider.value;

        currentSliderHeightA = sliderValue; //to log current height
        currentSliderHeightB = sliderValue; //has two as a rolling pointer, so doesn't use A if button is on cooldown, thus reverting to B
        changeFloodLevel(sliderValue, growthSpeed);
    }

        //method for UI buttons; 1 = clear water, 2 = grey, 3 = black, 4 = reset all
    public void complicatedButton(int whichFlood) { 
         if (buttonsOnCooldown && whichFlood < 5) return; //to prevent double-clicking and rapid clicking BUT ONLY IF non-recursive
        else {
            if (buttonDisableRoutine != null) StopCoroutine(buttonDisableRoutine);
            buttonDisableRoutine = StartCoroutine(buttonDisableRn()); //disables button for 0.3 seconds
        }

        if (whichFlood > 5) whichFlood -= 10; //remove recursive call tag, thus bypassing button cooldown call

        //reset slider cause it'll always reset no matter what
        //if (delayedSliderRoutine != null) StopCoroutine(delayedSliderRoutine);
      //  delayedSliderRoutine = StartCoroutine(resetSlider((whichFlood == 4 ? 0 : 5)));

        if (floodIsOn == 0 && whichFlood != 4) { //nothing is currently flooding, so button works normally
            if (!floodHeightSlider.gameObject.activeSelf) floodHeightSlider.gameObject.SetActive(true);
            turnOnFlood(whichFlood);
            floodIsOn = whichFlood; //log which flood type is currently active
        }
        else if (whichFlood == 4 && floodHeightSlider.gameObject.activeSelf) { //if reset button is pressed AND wasn't already reset to nothing
            turnOffFlood(true); //return the flood, and turn off water object
           // floodHeightSlider.gameObject.SetActive(false);
            floodIsOn = 0; //log that the flood was reset
        }
        else { //if one thing is flooding already
            turnOffFlood(false);//return the flood without turning off objects (save on instructions)
            if (whichFlood == floodIsOn) floodIsOn = 0; //if they pressed the same button to recall the flood
            else
            {
                /* If the user pressed a button that wasn't resetting a previous flood,
                    then return the previous flood and recursive call for the new flood.
                */
                floodIsOn = 0;
                complicatedButton(whichFlood + 10); //to distinguish if its a recursive call
            }

        }//endof else
    }//endof method

    #endregion


    #region grow code

    public void changeFloodLevel(int targetHeight, float duration) //easier to call than the ienumerator
    {   
        if (currentlyUsingSlider) { //if they keep messing with the slider when I'm not ready >:(
            floodHeightSlider.value = currentSliderHeightB;
            return;
        }

    /*    SoundManagerScript.Instance.stopSE();
        if (floodSounds != null) StopCoroutine(floodSounds); //add fade out audio methods to that
        floodSounds = StartCoroutine(SoundManagerScript.Instance.PlayAudioClip("waveRush", 2));*/


        //making sure that target height doesn't break the system via negative values or game-breaking values
        if (targetHeight < 0) targetHeight = 0;
        else if (targetHeight > floodHeightLimit) targetHeight = floodHeightLimit;
        //1 meter = 0.01f. 0 meters = sea level.
        float heightLevel_toMeters = 0.01f * targetHeight; //change desired height to meters


        if (growCoroutine != null)  { //if things get stopped prematurely
            StopCoroutine(growCoroutine);

            //so things dont break if these don't get reached
            sideCurrentScale = sideFront.localScale; 
        }
        growCoroutine = StartCoroutine(GrowCubeToHeight(heightLevel_toMeters, duration));
    }

    private IEnumerator GrowCubeToHeight(float targetHeight, float duration)
    {
        currentlyUsingSlider = true; //so the slider can't mess up calculations

        //init variables in loop here so they dont have to get reassigned over and over
        float elapsed = 0f, t = 0f;

        //start and end position for the top
        Vector3 startPos = topPlane.position;
        Vector3 endPos = new Vector3(startPos.x, seaLevel + targetHeight, startPos.z);

        //calculate new side scales and center position
        Vector3 center = (topPlane.position + bottomStartPos) / 2f;
        float heightRatio = (endPos.y - bottomStartPos.y) / (startPos.y - bottomStartPos.y); //new height by initial height
        float sidesTargetScaleZ = sideCurrentScale.z * heightRatio;

        while (elapsed < duration) { //based on time
            elapsed += Time.deltaTime;
            t = Mathf.Clamp01(elapsed / duration); //normalized time
            
            //move just the top upwards
            topPlane.position = Vector3.Lerp(startPos, endPos, elapsed / duration);
           
            //find the current center and height ratio for side scaling; uses lerp to maintain constant with other lerps
            center = Vector3.Lerp(((startPos + bottomStartPos) / 2f), ((endPos + bottomStartPos) / 2f), t); //previous center, ending center, t


            //scale and reposition side z axes with top plate positon
            sideFront.localScale = new Vector3(
                sideFront.localScale.x,
                sideFront.localScale.y,
                Mathf.Lerp(sideCurrentScale.z, sidesTargetScaleZ, t)); //only changing z axis with lerp
            sideFront.position = new Vector3(
                sideFront.position.x,
                Mathf.Lerp(sideFront.position.y, center.y, t),
                sideFront.position.z);

            sideBack.localScale = new Vector3(
                sideBack.localScale.x,
                sideBack.localScale.y,
                Mathf.Lerp(sideCurrentScale.z, sidesTargetScaleZ, t));
            sideBack.position = new Vector3(
                sideBack.position.x,
                Mathf.Lerp(sideBack.position.y, center.y, t),
                sideBack.position.z);

            sideLeft.localScale = new Vector3(
                sideLeft.localScale.x,
                sideLeft.localScale.y,
                Mathf.Lerp(sideCurrentScale.z, sidesTargetScaleZ, t));
            sideLeft.position = new Vector3(
                sideLeft.position.x,
                Mathf.Lerp(sideLeft.position.y, center.y, t),
                sideLeft.position.z);

            sideRight.localScale = new Vector3(
                sideRight.localScale.x,
                sideRight.localScale.y,
                Mathf.Lerp(sideCurrentScale.z, sidesTargetScaleZ, t));
            sideRight.position = new Vector3(
                sideRight.position.x,
                Mathf.Lerp(sideRight.position.y, center.y, t),
                sideRight.position.z);


            yield return null;
        }//endof while loop

        sideCurrentScale = sideFront.localScale; //so it doesn't reset to the starting scale every time
        currentlyUsingSlider = false;

        //clamp to final height to make sure?
        //topPlane.position = endPos; //Currently not going to clamp, as it might actually break congruency with the sides if the coroutine is stopped
        
    }

    #endregion

} //endof class
