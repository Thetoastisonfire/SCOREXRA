using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class floodMaterialChanger : MonoBehaviour
{
    public static floodMaterialChanger Instance { get; private set; }

    public MeshRenderer[] floodObjects = new MeshRenderer[11];
    public Material[] materialsToChooseFrom = new Material[3];
    public float[] materials_StartOpacity = new float[3]; //get starting opacity for materials
    private Material theMaterial; //should all share the same material so just one
    public int theMaterialIndex = 0;
    public GameObject cubeHolder;

    private Coroutine opacityRoutine = null;
    private Coroutine matTransition = null;

    #region initialization
    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }//endof if

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }
    // Start is called before the first frame update
    void Start()
    {
        if (floodObjects[0] != null) { //if not null, then get the cube's current material
            theMaterial = floodObjects[0].material; //should be clear by default
            theMaterialIndex = 1; //cause it should be clear, hopefully
        }
        for (int i = 0; i < 11; i++) { //set the whole cube to that current material
            if (floodObjects[i] == null) Debug.LogError("Flood Object " + i + " is missing.");
            else {
                floodObjects[i].sharedMaterial = theMaterial;
            }
        }   
        for (int i = 0; i < 3; i++) { //set the materials' starting opacity, then turn them off by default
            materials_StartOpacity[i] = materialsToChooseFrom[i].color.a;
            if (materials_StartOpacity[i] == 0f) Debug.LogError("opacity of material marked as zero");
   //         SetOpacity(materialsToChooseFrom[i], 0f, true); //turn off cube holder and make materials invisible
        }

        if (cubeHolder == null) Debug.LogError("object holding the cube is not assigned.");

    }//endof start method

    #endregion


    #region floodCube helper methods

    //lets other classes/methods access change material methods with a smooth transition
    public void changeMaterialFrontend(int whichFlood) {
        if (whichFlood < 1 || whichFlood > 3) {
            Debug.LogError("Invalid flood index");
            return;
        }
        //do cmt then cm
        if (matTransition != null) StopCoroutine(matTransition);
        matTransition = StartCoroutine(changeMatTransition(whichFlood)); //if coroutine running, stop prev routine and start new one
        
    }
    public IEnumerator changeMatTransition(int whichFlood) {
         //target opacity, duration, bool for turning off the cube
        changeOpacity(0f, 1f, false); //set opacity to zero without turning off objects

        yield return new WaitForSeconds(0.3f); //wait

        changeMaterial(whichFlood); //change the material WITHOUT changing opacity

        float desiredOpacity = materials_StartOpacity[theMaterialIndex - 1]; //set the desired opacity of new material
        changeOpacity(desiredOpacity, 3f, false); //slowly change opacity; the duration is arbitrary
    }

    public void changeMaterial(int whichFlood) { //add a method with smooth transition between floods
        Material ogMat = floodObjects[0].sharedMaterial; //keep the original material
        Material chosenMat = materialsToChooseFrom[whichFlood - 1]; //chosen material
        theMaterial = chosenMat; //just reference..? I think?

        for (int i = 0; i < floodObjects.Length; i++) //change materials
            if (floodObjects[i] != null)
                floodObjects[i].sharedMaterial = chosenMat;

        //material index hasn't changed yet, so it should still have the previous material's index
        SetOpacity(ogMat, materials_StartOpacity[theMaterialIndex - 1], false); //reset original material opacity
        theMaterialIndex = whichFlood;

        //SetOpacity(floodObjects[0].sharedMaterial, desiredOpacity, true);
    }

    //will allow other methods to access the opacity slider in this method
    public void changeOpacity(float targetOpacity, float duration, bool andTurnOffObject) {
        if (opacityRoutine != null) StopCoroutine(opacityRoutine);
        else opacityRoutine = StartCoroutine(SetOpacitySlow(floodObjects[0].sharedMaterial, targetOpacity, duration, andTurnOffObject));
    }

    #endregion


    #region OpacityMethods

    public void SetOpacity(Material targetMat, float targetOpacity, bool wantToToggleCube)
    { //set opacity immediately
        if (wantToToggleCube) { //if you want to mess with the cube's holder object
            if (targetOpacity == 0f) {//if mesh will be invisible
                if (cubeHolder != null && cubeHolder.activeSelf) cubeHolder.SetActive(false); //turn off the cube, if it is on
            }
            else if (Mathf.Approximately(targetOpacity, 0f) == false) {//if mesh will be visible and it wasn't previously
            if (cubeHolder != null && !cubeHolder.activeSelf) cubeHolder.SetActive(true); //turn on the cube, if it is off
            }
        }
        targetMat.color = new Color(targetMat.color.r,
                                            targetMat.color.g,
                                            targetMat.color.b,
                                            targetOpacity); //immediately set opacity for entire cube
    }//endof method

    private IEnumerator SetOpacitySlow(Material targetMat, float targetOpacity, float duration, bool wantToToggleCube) { //set opacity slower

        if (wantToToggleCube) {//if mesh will be visible and it wasn't previously
           if (cubeHolder != null && !cubeHolder.activeSelf) cubeHolder.SetActive(true); //turn on the cube
        }                             
        
        float elapsed = 0f, t = 0f, newOpacity = 0f; //elapsed time, mathClamp alpha, new alpha during while loop
        float startOpacity = targetMat.color.a;
        
        while (elapsed < duration) {
            elapsed += Time.deltaTime;
            t = Mathf.Clamp01(elapsed / duration);

            newOpacity = Mathf.Lerp(startOpacity, targetOpacity, t);
            targetMat.color = new Color (targetMat.color.r, 
                                            targetMat.color.g, 
                                            targetMat.color.b,  
                                            newOpacity); //just changes the opacity

            yield return null; //wait for operations
        }//endof while 

        targetMat.color = new Color (targetMat.color.r, 
                                            targetMat.color.g, 
                                            targetMat.color.b, 
                                            targetOpacity); //make sure its the correct opacity at the end
        if (wantToToggleCube) {
            if (targetOpacity == 0f) {//if mesh will be invisible
                if (cubeHolder != null && cubeHolder.activeSelf) cubeHolder.SetActive(false); //turn off the cube
            } 
        }


    } //endof method

    #endregion
}
