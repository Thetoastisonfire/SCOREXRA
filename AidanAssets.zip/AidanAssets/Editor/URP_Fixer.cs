using UnityEngine;
using UnityEditor;
using UnityEngine.Rendering.Universal;

public class URP_Fixer : EditorWindow
{
    [MenuItem("Tools/Fix URP Textures")]
    private static void FixURPSettings()
    {
        // Find all URP Assets in the project
        string[] guids = AssetDatabase.FindAssets("URP-HighFidelity t:UniversalRenderPipelineAsset");
        if (guids.Length == 0)
        {
            Debug.LogError("No URP-HighFidelity asset found!");
            return;
        }

        foreach (string guid in guids)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            var urpAsset = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(path);

            if (urpAsset == null)
            {
                Debug.LogWarning($"Could not load URP asset at {path}");
                continue;
            }

            bool changed = false;

            if (!urpAsset.supportsCameraDepthTexture)
            {
                urpAsset.supportsCameraDepthTexture = true;
                Debug.Log("Enabled Depth Texture");
                changed = true;
            }

            if (!urpAsset.supportsCameraOpaqueTexture)
            {
                urpAsset.supportsCameraOpaqueTexture = true;
                Debug.Log("Enabled Opaque Texture");
                changed = true;
            }

            if (urpAsset.opaqueDownsampling != Downsampling._2xBilinear)
            {
                Debug.LogWarning("Opaque Downsampling is not set to 2x Bilinear. " +
                          "This must be fixed manually in the URP asset. Path: " + path);
            }

            if (changed)
            {
                EditorUtility.SetDirty(urpAsset);
                AssetDatabase.SaveAssets();
                Debug.Log($"Updated URP settings in {path}");
            }
            else
            {
                Debug.Log("All settings already correct in URP asset.");
            }
        }
    }
}
