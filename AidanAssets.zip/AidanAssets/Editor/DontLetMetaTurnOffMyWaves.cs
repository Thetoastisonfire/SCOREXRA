using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

[InitializeOnLoad]
public class dontLetMetaTurnOffMyWaves
{
    private static void URPFixer()
    {
        EditorApplication.delayCall += FixURPSettings;
    }

    private static void FixURPSettings()
    {
        var urpAsset = GraphicsSettings.renderPipelineAsset as UniversalRenderPipelineAsset;
        if (urpAsset != null)
        {
            var serializedObject = new SerializedObject(urpAsset);
            serializedObject.FindProperty("m_RequireOpaqueTexture").boolValue = true;
            serializedObject.ApplyModifiedProperties();

            Debug.Log("URP Opaque Texture forced ON.");
        }
    }
}
