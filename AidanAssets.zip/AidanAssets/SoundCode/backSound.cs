using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class backSound : MonoBehaviour
{
    private bool playedSound = false;
    // Update is called once per frame
    void Update()
    {
        if (playedSound) return;
        else {
            if (SoundManagerScript.Instance.initComplete) {
                Debug.LogWarning("TRYING TO PLAY SOUND!!!");
                StartCoroutine(SoundManagerScript.Instance.PlayAudioClip("ES_Sunrise after Storms - Jay Taylor", 3));
                playedSound = true;
            }
        }
    }
}
